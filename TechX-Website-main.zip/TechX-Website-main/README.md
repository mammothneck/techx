# TechX-Website
Website for TechX NSUT
